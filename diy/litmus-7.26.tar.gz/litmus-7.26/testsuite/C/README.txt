T16: unaligned 16 bits accesses at cache boundary.
T64: unaligned 64 bits accesses at cache boundary.
U64: unaligned 64 bits accesses, inside cache.
