T64: unaligned 64 bits accesses at cache boundary.
