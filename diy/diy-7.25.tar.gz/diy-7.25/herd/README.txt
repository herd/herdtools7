** What is herd 'Seven' ? **

  Given assembler programs for Power, ARM, Arch64, or X86 (a litmus test)
  herd executes them on top of weak memory models.
  Models are described in simple text files.
           
  Herd is part of the diy tool suite.

** Home **
http://diy.inria.fr/
diy-devel@inria.fr

** Documentation **
Herd documentation is part of diy documentation
http://diy.inria.fr/doc/herd.html

** Compilation and installation **
See INSTALL.txt


** Contents of this release **
This release contains litmus sources.

** Law **

Herd 'seven' authors are Jade Alglave and Luc Maranget.

Copyright 2010-present: Institut National de Recherche en Informatique et
en Automatique, and the authors.

herd7 is released under the terms of the CeCILL-B free software license
agreement. See file LICENSE.txt
